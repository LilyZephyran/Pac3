AddCSLuaFile()
DEFINE_BASECLASS("base_anim")

local FLYING_SEQ, FLYING_SEQ_DUR

ENT.PrintName = "SCP-1762"
ENT.Category = "Veeds & Feeps"
ENT.Spawnable = true
ENT.AutomaticFrameAdvance = true

if SERVER then
	function ENT:Initialize()
		self:SetModel("models/veeds/scp1762/scp1762.mdl")
		self:SetUseType(SIMPLE_USE)
		self:PhysicsInit(SOLID_VPHYSICS) 
		self:SetMoveType(MOVETYPE_VPHYSICS) 
		self:SetSolid(SOLID_VPHYSICS)
		self:PhysWake()
		
		if not FLYING_SEQ and not FLYING_SEQ_DUR then
			FLYING_SEQ, FLYING_SEQ_DUR = self:LookupSequence("vole")
		end
	end
	
	function ENT:Use(activator)
		if activator:IsPlayer() and (self.NextFly or 0) <= CurTime() then
			self:ResetSequence(FLYING_SEQ)
			self.NextFly = CurTime() + FLYING_SEQ_DUR
		end
	end
	
	function ENT:Think()
		self:NextThink(CurTime()) -- For the animation tick
		return true
	end
end

