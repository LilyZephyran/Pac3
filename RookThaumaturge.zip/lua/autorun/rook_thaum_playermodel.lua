-- Rook (SCP Foundation thaumaturge) player model registration
player_manager.AddValidModel( "Rook (Thaumaturge)", "models/player/rook_thaum/rook.mdl" )
player_manager.AddValidHands( "Rook (Thaumaturge)", "models/weapons/c_arms_citizen.mdl", 1, "0000000" )
list.Set( "PlayerOptionsModel", "Rook (Thaumaturge)", "models/player/rook_thaum/rook.mdl" )
