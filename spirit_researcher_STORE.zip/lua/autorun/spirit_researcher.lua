player_manager.AddValidModel("Gothic Spirit Researcher", "models/spirit_researcher/spirit_researcher.mdl")
list.Set("PlayerOptionsModel", "Gothic Spirit Researcher", "models/spirit_researcher/spirit_researcher.mdl")
