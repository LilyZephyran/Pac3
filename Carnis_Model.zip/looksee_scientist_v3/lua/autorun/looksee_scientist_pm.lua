-- Registers the Look-See-headed scientist as a selectable playermodel.
player_manager.AddValidModel("Scientist (Look-See)", "models/scp/_scientist_1_looksee.mdl")
list.Set("PlayerOptionsModel", "Scientist (Look-See)", "models/scp/_scientist_1_looksee.mdl")
