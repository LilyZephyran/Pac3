-- Eirwen playermodel
player_manager.AddValidModel( "Eirwen", "models/player/eirwen/eirwen.mdl" )
list.Set( "PlayerOptionsModel", "Eirwen", "models/player/eirwen/eirwen.mdl" )
player_manager.AddValidHands( "Eirwen", "models/weapons/c_arms_eirwen.mdl", 0, "00000000" )
local Category = "Eirwen"
list.Set( "NPC", "npc_eirwen_friendly", { Name = "Eirwen", Class = "npc_citizen", Model = "models/player/eirwen/eirwen.mdl", Health = "150", KeyValues = { citizentype = 4 }, Category = Category } )
